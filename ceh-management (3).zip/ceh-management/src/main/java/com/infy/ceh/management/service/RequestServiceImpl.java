package com.infy.ceh.management.service;

import com.infy.ceh.management.controller.RequestController;
import com.infy.ceh.management.repository.RequestRepository;
import org.apache.tomcat.util.threads.ThreadPoolExecutor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

@Service
public class RequestServiceImpl implements RequestService {

    private static final Logger logger = LoggerFactory.getLogger(RequestController.class);
    private static final int QUEUE_CAPACITY = 10000;
    private BlockingQueue<JSONObject> requestQueue = new LinkedBlockingQueue<JSONObject>(QUEUE_CAPACITY);

    private final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
            10, 50, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>()
    );

    @Autowired
    private RequestRepository requestRepository;

    @Override
    public void receiveRequest(JSONObject request) {
        try {
            logger.debug("Receive request triggered");
            requestQueue.put(request);
            threadPoolExecutor.execute(this::processRequest);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Failed to queue the request", e);
        }
    }

    public void processRequest() {
        logger.debug("Thread pool triggered on-demand");
        JSONObject request = requestQueue.poll();
        if (request != null) {
            try {
                requestRepository.saveRequest(request);
            } catch (Exception e) {
                // Handle failed processing (e.g., log, retry, move to a dead-letter queue)
            }
        }
    }

    @PreDestroy
    public void shutDown() {
        threadPoolExecutor.shutdown();
        try {
            if (!threadPoolExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                threadPoolExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            threadPoolExecutor.shutdownNow();
        }
    }
}
