package com.infy.ceh.management.controller;

import com.infy.ceh.management.service.RequestService;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RequestController {

    private static final Logger logger = LoggerFactory.getLogger(RequestController.class);

    @Autowired
    private RequestService requestService;

    @PostMapping("/sendrequest")
    public String receiveRequest(@RequestBody String requestBody, @RequestParam String type) throws JSONException {
        logger.debug("type: "+type);
        JSONObject request = new JSONObject(requestBody);
        request.put("type", type);
        logger.debug("Received request: "+request);
        requestService.receiveRequest(request);
        return "Request received";
    }
}