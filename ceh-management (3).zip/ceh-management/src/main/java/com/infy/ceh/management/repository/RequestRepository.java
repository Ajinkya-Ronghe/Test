package com.infy.ceh.management.repository;

import org.json.JSONException;
import org.json.JSONObject;

public interface RequestRepository {
    void saveRequest(JSONObject request) throws Exception;
}