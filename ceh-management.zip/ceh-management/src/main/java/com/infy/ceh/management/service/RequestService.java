package com.infy.ceh.management.service;

import com.infy.ceh.management.domain.Request;

public interface RequestService {
    void receiveRequest(Request request);
    void processRequest();
}