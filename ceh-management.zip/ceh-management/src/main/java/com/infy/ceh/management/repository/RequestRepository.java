package com.infy.ceh.management.repository;

import com.infy.ceh.management.domain.Request;

public interface RequestRepository {
    void saveRequest(Request request);
}