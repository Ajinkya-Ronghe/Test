package com.infy.ceh.management.controller;

import com.infy.ceh.management.domain.Request;
import com.infy.ceh.management.service.RequestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RequestController {

    private static final Logger logger = LoggerFactory.getLogger(RequestController.class);

    @Autowired
    private RequestService requestService;

    @PostMapping("/sendrequest")
    public String receiveRequest(@RequestBody Request request) {
        logger.debug("Received request: {}", request);
        requestService.receiveRequest(request);
        return "Request received";
    }
}