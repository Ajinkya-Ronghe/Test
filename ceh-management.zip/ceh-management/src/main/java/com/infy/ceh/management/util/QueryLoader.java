package com.infy.ceh.management.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

@Component
public class QueryLoader {

    @Value("classpath:queries.xml")
    private org.springframework.core.io.Resource resource;

    private Map<String, String> queries = new HashMap<>();

    @PostConstruct
    public void init() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(resource.getInputStream());

        NodeList nodeList = document.getElementsByTagName("query");
        for (int i = 0; i < nodeList.getLength(); i++) {
            String id = nodeList.item(i).getAttributes().getNamedItem("id").getNodeValue();
            String query = nodeList.item(i).getTextContent();
            queries.put(id, query);
        }
    }

    public String getQuery(String id) {
        return queries.get(id);
    }
}