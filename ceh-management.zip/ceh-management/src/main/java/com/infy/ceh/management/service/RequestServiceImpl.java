package com.infy.ceh.management.service;

import com.infy.ceh.management.domain.Request;
import com.infy.ceh.management.repository.RequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@Service
public class RequestServiceImpl implements RequestService {

    private static final int QUEUE_CAPACITY = 10000;

    private BlockingQueue<Request> requestQueue = new LinkedBlockingQueue<>(QUEUE_CAPACITY);

    @Autowired
    private RequestRepository requestRepository;

    @Override
    public void receiveRequest(Request request) {
        try {
            requestQueue.put(request);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Failed to queue the request", e);
        }
    }

    @Async
    @Scheduled(fixedRate = 100)
    @Override
    public void processRequest() {
        Request request;
        while ((request = requestQueue.poll()) != null) {
            try {
                requestRepository.saveRequest(request);
            } catch (Exception e) {
                // Handle failed processing (e.g., log, retry, move to a dead-letter queue)
            }
        }
    }
}