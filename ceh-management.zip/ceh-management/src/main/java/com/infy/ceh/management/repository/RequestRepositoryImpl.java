package com.infy.ceh.management.repository;

import com.infy.ceh.management.domain.Request;
import com.infy.ceh.management.util.QueryLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class RequestRepositoryImpl implements RequestRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private QueryLoader queryLoader;

    @Override
    public void saveRequest(Request request) {
        String sql = queryLoader.getQuery("saveRequest");
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("createDate", request.getCreateDate())
                .addValue("dataType", request.getDataType())
                .addValue("jsonMetadataTypeId", request.getJsonMetadataTypeId())
                .addValue("reqName", request.getReqName())
                .addValue("jsonTextData", request.getJsonTextData())
                .addValue("dataIdentifier", request.isDataIdentifier())
                .addValue("status", request.getStatus());
        namedParameterJdbcTemplate.update(sql, params);
    }
}