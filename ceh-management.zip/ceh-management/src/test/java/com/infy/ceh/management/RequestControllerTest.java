package com.infy.ceh.management;

import com.infy.ceh.management.controller.RequestController;
import com.infy.ceh.management.domain.Request;
import com.infy.ceh.management.service.RequestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.any;

@ExtendWith(SpringExtension.class)
@WebMvcTest(RequestController.class)
public class RequestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RequestService requestService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testReceiveRequest() throws Exception {
        Request request = new Request();
        request.setReqName("Test Request");

        doNothing().when(requestService).receiveRequest(any(Request.class));

        mockMvc.perform(MockMvcRequestBuilders.post("/api/sendrequest")
                .contentType("application/json")
                .content("{\"reqName\": \"Test Request\"}"))
                .andExpect(status().isOk());
    }
}