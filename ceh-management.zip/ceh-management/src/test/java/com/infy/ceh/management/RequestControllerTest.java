package com.infy.ceh.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import com.infy.ceh.management.controller.RequestController;
import com.infy.ceh.management.domain.Request;
import com.infy.ceh.management.service.RequestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.MockMvc;

public class RequestControllerTest {

    private MockMvc mockMvc;
    private RequestService requestService;

    @BeforeEach
    public void setUp() {
        requestService = Mockito.mock(RequestService.class);
        RequestController requestController = new RequestController(requestService);
        mockMvc = standaloneSetup(requestController).build();
    }

    @Test
    public void testReceiveRequest() throws Exception {
        Request request = new Request();
        request.setDataType("test");
        request.setJsonMetadataTypeId(1);
        request.setReqName("test request");
        request.setJsonTextData("{"key":"value"}");
        request.setDataIdentifier(true);
        request.setStatus("P");

        mockMvc.perform(post("/api/sendrequest")
                .contentType("application/json")
                .content("{"dataType":"test","jsonMetadataTypeId":1,"reqName":"test request","jsonTextData":"{\"key\":\"value\"}","dataIdentifier":true,"status":"P"}"))
                .andExpect(status().isOk());
    }
}